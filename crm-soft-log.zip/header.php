<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
    <link rel="stylesheet" href="<?php echo $styleSheet; ?>">
	<?php $title = 'CRM Soft & Log'; ?>
	<title><?php echo $title; ?></title>
</head>
<body>
	<header id="mainTitle">
		<h1><a href="<?php echo $homePage; ?>" title="<?php echo $title; ?>"><?php echo $title; ?></a></h1>
	</header>
	<div id="mainContent">