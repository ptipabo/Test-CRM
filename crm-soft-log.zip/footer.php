<footer><p><?php echo $title ?> 2020</p></footer>
</body>
</html>